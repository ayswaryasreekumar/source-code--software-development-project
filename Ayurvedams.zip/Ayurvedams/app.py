from flask import Flask, render_template,request
import sqlite3
import threading
import smtplib
import datetime
import pandas as pd
admin=False
doctor=False
patient=False
doc=None
def connect_db():
    conn = sqlite3.connect('Database.db', check_same_thread=False)
    return conn 
def mail(name,to,pwd):
    ob=smtplib.SMTP("smtp.gmail.com",587)
    ob.starttls()
    ob.login("covnetryayurvedaclinic@gmail.com","ABCD123@")  # please mention you email and password here
    subject="Welcome to Ayurveda Clinic! Your Account Details Inside"
    body=f'''Dear {name},\n\nWe are delighted to welcome you to the team at Ayurveda!
      As a new member, we have created your account on our Clinic's website, granting you access to our comprehensive healthcare system and enabling seamless communication within our network.
      \n\n To log in to your account, please find your unique username and password details below: \n\n
      Emale : {to}
      password: {pwd} \n\n Please ensure that you keep this information secure and confidential. We recommend changing your password after your initial login for added security.\n\n
      Best regards,\n\n
      Dean of Ayurved \n\n'''
    mes="subject:{}\n\n{}".format(subject,body)
    listofadd=[to]
    ob.sendmail("covnetryayurvedaclinic@gmail.com",listofadd,mes)
    ob.quit()

def male_confirmation(name,to,doctor,date,time,email2):
    ob=smtplib.SMTP("smtp.gmail.com",587)
    ob.starttls()
    ob.login("covnetryayurvedaclinic@gmail.com","ABCD123@")  # please mention you email and password here
    subject="Appointment Confirmation"
    body=f"Dear {name},\n\nYour appointment has been scheduled with Dr. {doctor}.\n\nDetails:\nDoctor Name : Dr. {doctor}\nDate: {date}\nTime: {time}\n\nPlease arrive on time for your appointment.\n\nIf you have any questions or need to reschedule, please contact us : {email2}.\n\nBest regards,\nAyurveda Clinic"
    mes="subject:{}\n\n{}".format(subject,body)
    listofadd=[to]
    ob.sendmail("covnetryayurvedaclinic@gmail.com",listofadd,mes)
    ob.quit()
def male_doctor(name,to,doctor,date,time):
    ob=smtplib.SMTP("smtp.gmail.com",587)
    ob.starttls()
    ob.login("covnetryayurvedaclinic@gmail.com","ABCD123@")  # please mention you email and password here
    subject="Appointment Confirmation"
    body=f"Dear Dr. {doctor},\n\nYou have a new appointment scheduled.\n\nPatient Name: {name}\nDate: {date}\nTime: {time}\n\nPlease be prepared to attend to the patient at the scheduled time.\n\nBest regards,\nAyurveda Clinic"
    mes="subject:{}\n\n{}".format(subject,body)
    listofadd=[to]
    ob.sendmail("covnetryayurvedaclinic@gmail.com",listofadd,mes)
    ob.quit()
def new_shedule_mail(name,to,date,day,time):
    ob=smtplib.SMTP("smtp.gmail.com",587)
    ob.starttls()
    ob.login("covnetryayurvedaclinic@gmail.com","ABCD123@")  # please mention you email and password here
    subject="Updated Job Schedule"
    body=f"Dear Dr. {name},\n\n hope this email finds you well. I am writing to inform you about an update to your job schedule. Please take note of the following details:\n\nPatient Name: {name}\nDate: {date}\nDay: {day}\nTime: {time}\n\nThank you for your cooperation and flexibility. Your dedication to your work is greatly appreciated.\n\nBest regards,\nAyurveda Clinic"
    mes="subject:{}\n\n{}".format(subject,body)
    listofadd=[to]
    ob.sendmail("covnetryayurvedaclinic@gmail.com",listofadd,mes)
    ob.quit()
def report_mail(name,to,age,symptoms,diagnosis,treatment,payment):
    ob=smtplib.SMTP("smtp.gmail.com",587)
    ob.starttls()
    ob.login("covnetryayurvedaclinic@gmail.com","ABCD123@")  # please mention you email and password here
    subject="Your Report"
    body=f"Dear {name},\n\n" \
       f"We hope this email finds you well. We have reviewed your recent visit to our Clinic and would like to provide you with a report of your condition.\n\n" \
       f"Patient Name: {name}\n" \
       f"Age: {age}\n" \
       f"Symptoms: {symptoms}\n" \
       f"Diagnosis: {diagnosis}\n" \
       f"Treatment: {treatment}\n\n" \
       f"We recommend following the prescribed treatment plan. If you have any further questions or concerns, please feel free to contact us.\n\n" \
       f"Please find the details of the payment below:\n" \
       f"Amount: {payment}\n" \
       f"please go to our payment portal and pay ASAP..\n"\
       f"Thank you for choosing our clinic. We wish you a speedy recovery!\n\n" \
       f"Best regards,\n" \
       f"Ayurveda Clinic\n" 
    mes="subject:{}\n\n{}".format(subject,body)
    listofadd=[to]
    ob.sendmail("covnetryayurvedaclinic@gmail.com",listofadd,mes)
    ob.quit()  
 
def calculate_revenue(income):
    tax_rate = 0.2  # Assuming a 20% tax rate
    revenue = income - (income * tax_rate)
    return revenue 
app = Flask(__name__)
@app.route("/reminder")     
def send_reminder():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("SELECT email From appoinments")
    records=cursor.fetchall()
    to= [record[0] for record in records]
    ob=smtplib.SMTP("smtp.gmail.com",587)
    ob.starttls()
    ob.login("covnetryayurvedaclinic@gmail.com","ABCD123@")  # please mention you email and password here
    subject="Medication Reminder'"
    body=f'Dear Patient,\n\nThis is a friendly reminder to take your medications as prescribed.\n\nPlease follow the instructions provided by your healthcare provider.\n\nRegards,\nAyurveda Healthcare Provider'
    mes="subject:{}\n\n{}".format(subject,body)
    ob.sendmail("covnetryayurvedaclinic@gmail.com",to,mes)
    ob.quit()
    return render_template ("dean.html")
@app.route("/")
def base():
    return render_template("base.html")
@app.route("/logout")
def logout():
    global doctor,admin
    doctor=False
    admin=False
    return render_template("base.html")
@app.route("/home")
def home():
    global admin,doctor
    return render_template ("home.html",dean=admin,doctor=doctor)
@app.route("/about")
def about():
    global doctor, admin  # Assuming doctor and admin are global variables
    conn = connect_db()  # Assuming connect_db() is a function that establishes a database connection
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM history")
    records = cursor.fetchall()
    cursor.execute("SELECT  payment FROM history")
    record1=cursor.fetchall()
    payments = [float(record[0]) for record in record1]  # Extracting payment values from the records
    total_payment = sum(payments)  # Calculating the sum of payments
    revenue=calculate_revenue(total_payment)
    print(records)
    treat = records[-1][0]
    print(treat)  # Assuming you want to access the last column value of the first record
    conn.close()  # Closing the database connection

    return render_template("about.html", doctor=doctor, dean=admin, treat=treat, revenue=revenue)

@app.route("/login",methods=["GET","POST"])
def login():
    global admin,doctor,doc
    if request.method=="POST":
        email=request.form['email']
        passw=request.form['password']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("SELECT patient_name,Type From login WHERE email=? AND password=?",(email,passw))
        record=cursor.fetchone()
        if record:
            if record[1]=="dean":
                admin=True
                doctor=False
                return render_template('dean.html')
            elif record[1]=="doctor":
                doc=record[0]
                admin=False
                doctor=True 
                return render_template("doctor.html")
            else:
                return render_template("base.html")
        else:
            return render_template("login.html",msg="Invalid Credentials !") 
    return render_template ("login.html",doctor=doctor,dean=admin)        
@app.route("/new",methods=["GET","POST"])
def new_patient():
    global admin,doctor
    if request.method=="POST":
        print("reached")
        name=request.form['username'] 
        password=request.form['password']
        email=request.form['email']
        age=request.form['age']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("INSERT INTO login(patient_name,email,password,AGE) VALUES (?, ?, ?, ?)",(name, email, password ,age))
        conn.commit()
        return render_template("new_patient.html",msg="Patient Registered Successfully !",dean=admin,patient=patient)
    return render_template("new_patient.html",dean=admin,doctor=doctor)
@app.route("/dean")
def dean():
    return render_template("mgmt_pannel.html")
@app.route("/new_doctor",methods=['GET','POST'])
def new_doctor():
    if request.method=="POST":
        name=request.form['name']
        email=request.form['email']
        pwd=request.form['password']
        age=request.form['age']
        specialist=request.form['specialist']
        experience=request.form['experience']
        role=request.form['role']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("INSERT INTO doctors (name,email,password,specialist,experience,role)VALUES(?,?,?,?,?,?)",(name,email,pwd,specialist,experience,role))
        conn.commit()
        doc="doctor"
        cursor.execute("INSERT INTO login(patient_name,email,password,AGE,Type) VALUES (?, ?, ? ,? ,?)",(name, email, pwd ,age,doc))
        conn.commit()
        email_thread = threading.Thread(target=mail, args=(name,email,pwd))
        email_thread.start()
        return render_template("new_doctor_form.html",msg=f"Credentials send to Dr. {name}")
    return render_template("new_doctor_form.html")

@app.route("/shedule",methods=["GET",'POST'])
def shedule():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("SELECT name FROM doctors")
    results = cursor.fetchall()
    # Extract the names from the results and store them in a list
    names = [row[0] for row in results]
    conn.commit()
    if request.method=="POST":
        name=request.form['name']
        email=request.form['email']
        age=request.form['age']
        doctor=request.form['doctor']
        date=request.form['date']
        time=request.form['time']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("INSERT INTO appoinments (name,email,doctor_name,appointment_date,appointment_time,age)VALUES(?,?,?,?,?,?)",(name,email,doctor,date,time,age))
        conn.commit()
        cursor.execute("SELECT email FROM doctors WHERE name = ?",(doctor,))
        record=cursor.fetchone()
        doc_mail=record[0]
        email = threading.Thread(target=male_confirmation, args=(name,email,doctor,date,time,doc_mail))
        email.start()
        email2=threading.Thread(target=male_doctor,args=(name,doc_mail,doctor,date,time))
        email2.start()
        return render_template("shedule.html",doc=names,msg="Confirmed !")
    return render_template("shedule.html",doc=names)

@app.route("/my_patients")
def patients():
    global doctor,doc
    conn=connect_db()
    cursor=conn.cursor() 
    cursor.execute("SELECT name, age, appointment_date, appointment_time FROM appoinments WHERE doctor_name=?",(doc,))
    results = cursor.fetchall()
    df = pd.DataFrame(results, columns=['name','age','appointment_date','appointment_time'])
    name=df['name'].tolist()
    age=df['age'].tolist()
    date=df['appointment_date']
    time=df['appointment_time']
    print(name)
    return render_template("my_patient.html",name=name,age=age,date=date,time=time,doctor=doctor)
@app.route("/report",methods=['GET','POST'])
def report():
    if request.method=="POST":
        name=request.form['name']
        age=request.form['age']
        symptoms=request.form['symptoms']
        diagnosis=request.form['diagnosis']
        treatment=request.form['treatment']
        payment=request.form['payment']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("INSERT INTO treatment(name,age,symptoms,diagnosis,treatment,payment)VALUES(?,?,?,?,?,?)",(name,age,symptoms,diagnosis,treatment,payment)) 
        conn.commit()
        cursor.execute("INSERT INTO history(name,age,symptoms,diagnosis,treatment,payment)VALUES(?,?,?,?,?,?)",(name,age,symptoms,diagnosis,treatment,payment)) 
        conn.commit()
        cursor.execute("SELECT email from  appoinments where name=? and age=?",(name,age))
        record=cursor.fetchone()
        mailid=record[0]
        print(mailid)
        email3=threading.Thread(target=report_mail,args=(name,record[0],age,symptoms,diagnosis,treatment,payment)) 
        email3.start()
        conn.commit()
        cursor.execute("INSERT INTO payment (name,age,amount,pay)VALUES(?,?,?,?)",(name,age,payment,"pending"))
        conn.commit()
        return render_template("patient_report_creation_form.html",msg="Report send to Patient Mail !")
    return render_template("patient_report_creation_form.html")

@app.route("/pay",methods=['GET','POST'])
def payment():
    if request.method=="POST":
        name=request.form['name']
        age=request.form['age']
        amount=request.form['amount']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("UPDATE payment SET pay = 'Successfull' WHERE name=? and age=?",(name,age))
        conn.commit()
        return render_template("payment.html",msg="Payment Successfull !") 
    return render_template("payment.html")

@app.route("/our_staff")
def our_staff():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("SELECT name,email,specialist,role,experience FROM doctors")
    results = cursor.fetchall()
    df = pd.DataFrame(results, columns=['name','email','specialist','role','experience'])
    name=df['name'].tolist()
    email=df['email'].tolist()
    specialist=df['specialist'].tolist()
    role=df['role'].tolist()
    experience=df['experience'].tolist()
    return render_template("staff.html",name=name,email=email,specialist=specialist,role=role,experience=experience)
@app.route("/our_staff/<string:name>")
def dele_our_staff(name):
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("DELETE FROM doctors WHERE name=?",(name,))
    conn.commit()
    return render_template("dean.html")
@app.route("/all_appoint")
def all_appointment():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("SELECT name,email,doctor_name,appointment_date,appointment_time FROM appoinments")
    results = cursor.fetchall()
    df = pd.DataFrame(results, columns=['name','email','doctor_name','appointment_date','appointment_time'])
    name=df['name'].tolist()
    email=df['email'].tolist()
    doctor=df['doctor_name'].tolist()
    date=df['appointment_date'].tolist()
    time=df['appointment_time'].tolist()
    return render_template("all_appointment.html",name=name,email=email,doctor=doctor,date=date,time=time)
@app.route("/dele/<string:name>")
def dele_appoin(name):
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("DELETE FROM appoinments WHERE name=?",(name,))
    conn.commit()
    return render_template("doctor.html")

@app.route("/payment_details")
def payment_details():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("Select name,age,amount,pay from payment")
    results=cursor.fetchall()
    df=pd.DataFrame(results,columns=['name','age','amount','pay'])
    name=df['name'].tolist()
    age=df['age'].tolist()
    amount=df['amount'].tolist()
    pay=df['pay'].tolist()
    return render_template("payment_details.html",name=name,age=age,amount=amount,pay=pay)
@app.route("/payment/<string:name>")
def dele_pamant(name):
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("DELETE FROM payment WHERE name=?",(name,))
    conn.commit()
    return render_template("dean.html")
@app.route("/patient_history")
def history():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("SELECT name,symptoms,diagnosis,treatment,payment From history")
    results=cursor.fetchall()
    df=pd.DataFrame(results,columns=['name','symptoms','diagnosis','treatment','payment'])
    name=df['name'].tolist()
    symptoms=df['symptoms'].tolist()
    diagnosis=df['diagnosis'].tolist()
    treatment=df['treatment'].tolist()
    payment=df['payment'].tolist()
    return render_template("history.html",name=name,symptoms=symptoms,diagnosis=diagnosis,treatment=treatment,payment=payment)

@app.route("/shedule_new",methods=['GET','POST'])
def shedule_job():
    if request.method=='POST':
        name=request.form['name']
        email=request.form['email']
        date=request.form['date']
        day=request.form['day']
        job_timing=request.form['job_timing']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("INSERT INTO shedule_job (name,date,day,job_timing)VALUES(?,?,?,?)",(name,date,day,job_timing))
        conn.commit()
        email4=threading.Thread(target=new_shedule_mail,args=(name,email,date,day,job_timing)) 
        email4.start()
        return render_template("new_shedule_form.html",msg=f"New Shedule Send to Dr. {name} via mail.")
    return render_template("new_shedule_form.html")    
@app.route("/shedule_jobs")
def jobs():
    conn=connect_db()
    cursor=conn.cursor()
    cursor.execute("SELECT name,date,day,job_timing FROM shedule_job")
    results=cursor.fetchall()
    df=pd.DataFrame(results,columns=['name','date','day','job_timing'])
    name=df['name'].tolist()
    date=df['date'].tolist()
    day=df['day'].tolist()
    job_timing=df['job_timing'].tolist()
    return render_template("job_shedule.html",name=name,date=date,day=day,job_timing=job_timing)
@app.route("/edit/<string:name>",methods=['GET','POST'])
def edit(name):
    if request.method=="POST":
        email=request.form['email']
        date=request.form['date']
        day=request.form['day']
        job_timing=request.form['job_timing']
        conn=connect_db()
        cursor=conn.cursor()
        cursor.execute("UPDATE shedule_job SET date = ?, day = ?, job_timing =? WHERE name = ?", (date, day, job_timing, name))
        email5=threading.Thread(target=new_shedule_mail,args=(name,email,date,day,job_timing)) 
        email5.start()
        return render_template("Edit_doctor_shedule.html",msg=f"Updated Shedule Send to Dr. {name} via mail.")
    return render_template("Edit_doctor_shedule.html",name=name)

if __name__=="__main__":
    app.run(debug=True)
