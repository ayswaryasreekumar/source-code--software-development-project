CREATE TABLE login (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  patient_name NOT NULL,
  email TEXT NOT NULL,
  password TEXT NOT NULL,
  AGE INTEGER NOT NULL
);
INSERT INTO login (patient_name, email, password, AGE,Type) VALUES ('gokul', 'gokulvijaie.uk@gmail.com', '4321',28,'doctor');
UPDATE login SET Type = 'dean' WHERE id = 3;
ALTER TABLE login ADD COLUMN Type text;
Select * from login;
DELETE FROM login WHERE id =5;




-- query for new staff listed by the dean....

CREATE TABLE doctors (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  email TEXT,
  specialist TEXT,
  role Text,
  experience INTEGER
);
ALTER TABLE doctors ADD COLUMN password text;
DELETE FROM doctors WHERE id =4;
UPDATE doctors SET name='himanshu' WHERE id = 2;

SELECT * from doctors



--query for appoinment
CREATE TABLE appoinments (
id INTEGER PRIMARY KEY AUTOINCREMENT,
name Text,
email text,
doctor_name text,
appointment_date text,
appointment_time text
)
select * From appoinments
UPDATE appoinments SET doctor_name = 'himanshu' WHERE id = 2;
ALTER TABLE appoinments ADD COLUMN age text;

SELECT name,age,appointment_date,appointment_time FROM appoinments WHERE doctor_name='himanshu'
CREATE TABLE treatment(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name Text,
symptoms Text,
diagnosis Text,
treatment Text,
payment Text
)
ALTER TABLE treatment  ADD COLUMN age text;
select *  from treatment
DELETE FROM treatment WHERE id =2;
CREATE TABLE history(
id INTEGER PRIMARY KEY AUTOINCREMENT,
name Text,
symptoms Text,
diagnosis Text,
treatment Text,
payment Text
)
INSERT INTO history (name, symptoms, diagnosis, treatment, payment)
VALUES ('jack', 'fever', 'blood test', 'Naproxen', '100');
ALTER TABLE history ADD COLUMN age text;

CREATE TABLE payment(
name Text,
age Text,
amount text,
pay text
)
SELECT * FROM treatment
DELETE FROM treatment WHERE id =4;
INSERT INTO payment(name,age,amount,pay)VALUES('jack','19','100','pending')


date,day,dr.name,job-timing,edit
create TABLE shedule_job (name text,date text,day text,job_timing text)